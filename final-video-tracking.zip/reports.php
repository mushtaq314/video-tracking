<?php
/**
 * Video Tracking Reports Dashboard
 *
 * This page displays comprehensive analytics and reports for video tracking sessions.
 * It provides an overview of all user sessions with aggregated metrics and detailed
 * session information. The interface includes summary statistics and links to
 * individual session details.
 */

require_once "db.php";

/**
 * Format milliseconds to minutes with decimal precision
 *
 * @param int $milliseconds Time in milliseconds
 * @return string Formatted time string
 */
function formatWatchTime($milliseconds) {
    return number_format($milliseconds / 60000, 2);
}

/**
 * Format timestamp for display
 *
 * @param string $timestamp Database timestamp
 * @return string Formatted date/time string
 */
function formatTimestamp($timestamp) {
    // Create a DateTime object from the timestamp and set the timezone to GMT
    $date = new DateTime($timestamp, new DateTimeZone('GMT'));

    // Set the timezone to IST (Indian Standard Time)
    $date->setTimezone(new DateTimeZone('Asia/Kolkata'));

    // Format the timestamp in the desired format
    return $date->format('M j, Y g:i A');
}

/**
 * Calculate summary statistics from sessions data
 *
 * @param array $sessions Array of session data
 * @return array Summary statistics
 */
function calculateSummaryStats($sessions) {
    if (empty($sessions)) {
        return [
            'total_sessions' => 0,
            'total_watch_time' => 0,
            'avg_watch_time' => 0,
            'total_plays' => 0,
            'total_pauses' => 0,
            'total_tab_changes' => 0,
            'avg_session_duration' => 0
        ];
    }

    $stats = [
        'total_sessions' => count($sessions),
        'total_watch_time' => 0,
        'total_plays' => 0,
        'total_pauses' => 0,
        'total_tab_changes' => 0,
        'total_page_time' => 0
    ];

    foreach ($sessions as $session) {
        $stats['total_watch_time'] += $session['watch_ms'];
        $stats['total_plays'] += $session['total_plays'];
        $stats['total_pauses'] += $session['total_pauses'];
        $stats['total_tab_changes'] += $session['total_tab_changes'];
        $stats['total_page_time'] += $session['total_time_on_page'];
    }

    $stats['avg_watch_time'] = $stats['total_sessions'] > 0 ?
        $stats['total_watch_time'] / $stats['total_sessions'] : 0;
    $stats['avg_session_duration'] = $stats['total_sessions'] > 0 ?
        $stats['total_page_time'] / $stats['total_sessions'] : 0;

    return $stats;
}

try {
    // Fetch all sessions with error handling
    $stmt = $pdo->prepare("
        SELECT
            session_id,
            last_position,
            watch_ms,
            total_time_on_page,
            total_plays,
            total_pauses,
            total_tab_changes,
            updated_at
        FROM video_sessions
        ORDER BY updated_at DESC
    ");
    $stmt->execute();
    $sessions = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Calculate summary statistics
    $summaryStats = calculateSummaryStats($sessions);

} catch (PDOException $e) {
    // Log error and show user-friendly message
    error_log("Database error in reports.php: " . $e->getMessage());
    die("Error loading reports. Please try again later.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Tracking Reports - Analytics Dashboard</title>
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 300;
        }

        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .content {
            padding: 40px;
        }

        .summary-section {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 30px;
            margin-bottom: 40px;
        }

        .summary-title {
            font-size: 1.8em;
            margin-bottom: 25px;
            color: #333;
            text-align: center;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            border-left: 4px solid #667eea;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }

        .stat-value {
            font-size: 2.5em;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 0.9em;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 600;
        }

        .stat-unit {
            font-size: 0.8em;
            color: #999;
            margin-left: 5px;
        }

        .sessions-section {
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 1.8em;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .table-container {
            overflow-x: auto;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #667eea;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85em;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        tr:nth-child(even) {
            background: #f8f9fa;
        }

        tr:hover {
            background: #e3f2fd;
            transition: background-color 0.3s ease;
        }

        .session-id {
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
            color: #555;
        }

        .time-cell {
            font-weight: 600;
            color: #333;
        }

        .count-cell {
            text-align: center;
            font-weight: 600;
        }

        .action-cell {
            text-align: center;
        }

        .btn {
            display: inline-block;
            padding: 8px 16px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background: #5a67d8;
        }

        .no-data {
            text-align: center;
            padding: 60px;
            color: #666;
            font-style: italic;
        }

        .no-data i {
            font-size: 3em;
            margin-bottom: 20px;
            display: block;
            color: #ddd;
        }

        .footer {
            background: #343a40;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 0.9em;
        }

        .footer a {
            color: #667eea;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .refresh-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }

        .refresh-btn:hover {
            background: #218838;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 2em;
            }

            .content {
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .stat-card {
                padding: 20px;
            }

            .stat-value {
                font-size: 2em;
            }

            th, td {
                padding: 10px 8px;
                font-size: 0.9em;
            }

            .table-container {
                font-size: 0.8em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Video Tracking Reports</h1>
            <p>Comprehensive analytics dashboard for video engagement</p>
        </div>

        <div class="content">
            <a href="javascript:location.reload()" class="refresh-btn">🔄 Refresh Data</a>

            <div class="summary-section">
                <h2 class="summary-title">📈 Summary Statistics</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $summaryStats['total_sessions']; ?></div>
                        <div class="stat-label">Total Sessions</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo formatWatchTime($summaryStats['total_watch_time']); ?><span class="stat-unit">min</span></div>
                        <div class="stat-label">Total Watch Time</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo formatWatchTime($summaryStats['avg_watch_time']); ?><span class="stat-unit">min</span></div>
                        <div class="stat-label">Avg Watch Time</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $summaryStats['total_plays']; ?></div>
                        <div class="stat-label">Total Plays</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $summaryStats['total_pauses']; ?></div>
                        <div class="stat-label">Total Pauses</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $summaryStats['total_tab_changes']; ?></div>
                        <div class="stat-label">Tab Changes</div>
                    </div>
                </div>
            </div>

            <div class="sessions-section">
                <h2 class="section-title">🎬 Session Details</h2>

                <?php if (empty($sessions)): ?>
                    <div class="no-data">
                        <i>📊</i>
                        <p>No tracking sessions found yet.</p>
                        <p>Start using the video player to see session data here.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Session ID</th>
                                    <th>Last Position</th>
                                    <th>Watch Time</th>
                                    <th>Page Time</th>
                                    <th>Plays</th>
                                    <th>Pauses</th>
                                    <th>Tab Changes</th>
                                    <th>Last Updated</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($sessions as $session): ?>
                                    <tr>
                                        <td class="session-id"><?php echo htmlspecialchars($session['session_id']); ?></td>
                                        <td class="time-cell"><?php echo number_format($session['last_position'], 1); ?>s</td>
                                        <td class="time-cell"><?php echo formatWatchTime($session['watch_ms']); ?> min</td>
                                        <td class="time-cell"><?php echo formatWatchTime($session['total_time_on_page']); ?> min</td>
                                        <td class="count-cell"><?php echo $session['total_plays']; ?></td>
                                        <td class="count-cell"><?php echo $session['total_pauses']; ?></td>
                                        <td class="count-cell"><?php echo $session['total_tab_changes']; ?></td>
                                        <td><?php echo formatTimestamp($session['updated_at']); ?></td>
                                        <td class="action-cell">
                                            <a href="session_details.php?id=<?php echo urlencode($session['session_id']); ?>" class="btn">View Details</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer">
            <p>Video Tracking Analytics &copy; 2025 | <a href="index.html">Back to Player</a> | <a href="webinar_analytics.php">Webinar Analytics</a></p>
        </div>
    </div>
</body>
</html>
