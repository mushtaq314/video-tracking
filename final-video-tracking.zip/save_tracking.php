<?php
/**
 * Video Tracking Data Saver
 *
 * This script receives tracking data from the frontend via POST requests,
 * validates the data, and saves it to the database. It handles both session
 * summaries and individual events in a transactional manner for data integrity.
 */

// Set response content type to JSON
header('Content-Type: application/json');

// Enable CORS only for specific domains in production
// Uncomment and modify the line below for production use
// header('Access-Control-Allow-Origin: https://yourdomain.com');

// Get raw POST data from the request body
$rawInput = file_get_contents('php://input');

// Decode JSON data
$inputData = json_decode($rawInput, true);

// Validate JSON input
if ($inputData === null) {
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Invalid JSON data received']);
    exit;
}

// Include database connection
require_once 'db.php';

// Extract and validate required data fields
$sessionId = isset($inputData['session_id']) ? trim($inputData['session_id']) : null;
$sessionSummary = isset($inputData['summary']) ? $inputData['summary'] : null;
$events = isset($inputData['events']) && is_array($inputData['events']) ? $inputData['events'] : [];

// Validate session ID
if (!$sessionId) {
    http_response_code(400);
    echo json_encode(['error' => 'Session ID is required']);
    exit;
}

// Validate session summary if provided
if ($sessionSummary && !is_array($sessionSummary)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid session summary format']);
    exit;
}

try {
    // Begin database transaction for atomic operations
    $pdo->beginTransaction();

    // Insert or update session summary
    if ($sessionSummary) {
        updateSessionSummary($pdo, $sessionId, $sessionSummary);
    }

    // Insert individual events
    $eventsInserted = insertEvents($pdo, $sessionId, $events);

    // Commit the transaction
    $pdo->commit();

    // Return success response
    echo json_encode([
        'success' => true,
        'message' => 'Tracking data saved successfully',
        'events_inserted' => $eventsInserted
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $pdo->rollBack();

    // Log error for debugging (use proper logging in production)
    error_log("Tracking save error for session {$sessionId}: " . $e->getMessage());

    // Return error response
    http_response_code(500); // Internal Server Error
    echo json_encode(['error' => 'Failed to save tracking data']);
}

/**
 * Update or insert session summary data
 *
 * @param PDO $pdo Database connection
 * @param string $sessionId Unique session identifier
 * @param array $summary Session summary data
 */
function updateSessionSummary($pdo, $sessionId, $summary) {
    // Prepare UPSERT query for session data
    $query = "INSERT INTO video_sessions
        (session_id, last_position, watch_ms, total_time_on_page, total_plays, total_pauses, total_tab_changes, updated_at)
        VALUES (:session_id, :last_position, :watch_ms, :total_time_on_page, :total_plays, :total_pauses, :total_tab_changes, NOW())
        ON DUPLICATE KEY UPDATE
            last_position = VALUES(last_position),
            watch_ms = VALUES(watch_ms),
            total_time_on_page = VALUES(total_time_on_page),
            total_plays = VALUES(total_plays),
            total_pauses = VALUES(total_pauses),
            total_tab_changes = VALUES(total_tab_changes),
            updated_at = NOW()";

    $stmt = $pdo->prepare($query);

    // Bind parameters with defaults
    $stmt->execute([
        ':session_id' => $sessionId,
        ':last_position' => isset($summary['last_position']) ? (float)$summary['last_position'] : 0,
        ':watch_ms' => isset($summary['watch_ms']) ? (int)$summary['watch_ms'] : 0,
        ':total_time_on_page' => isset($summary['total_time_on_page']) ? (int)$summary['total_time_on_page'] : 0,
        ':total_plays' => isset($summary['total_plays']) ? (int)$summary['total_plays'] : 0,
        ':total_pauses' => isset($summary['total_pauses']) ? (int)$summary['total_pauses'] : 0,
        ':total_tab_changes' => isset($summary['total_tab_changes']) ? (int)$summary['total_tab_changes'] : 0
    ]);
}

/**
 * Insert individual tracking events
 *
 * @param PDO $pdo Database connection
 * @param string $sessionId Unique session identifier
 * @param array $events Array of event data
 * @return int Number of events inserted
 */
function insertEvents($pdo, $sessionId, $events) {
    if (empty($events)) {
        return 0;
    }

    // Prepare insert query for events
    $query = "INSERT INTO video_events
        (session_id, event_type, event_time, ts, meta)
        VALUES (:session_id, :event_type, :event_time, :timestamp, :meta)";

    $stmt = $pdo->prepare($query);
    $eventsInserted = 0;

    foreach ($events as $event) {
        // Validate and sanitize event data
        $eventType = isset($event['type']) ? trim($event['type']) : 'unknown';
        $eventTime = isset($event['time']) ? (float)$event['time'] : 0;
        $timestamp = isset($event['ts']) ? $event['ts'] : date('c');
        $meta = isset($event['payload']) ? json_encode($event['payload']) : json_encode(new stdClass());

        // Execute insert
        $stmt->execute([
            ':session_id' => $sessionId,
            ':event_type' => $eventType,
            ':event_time' => $eventTime,
            ':timestamp' => $timestamp,
            ':meta' => $meta
        ]);

        $eventsInserted++;
    }

    return $eventsInserted;
}
