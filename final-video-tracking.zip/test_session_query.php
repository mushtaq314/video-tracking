<?php
require_once "db.php";

try {
    // Query for sessions that have events with 'from_seconds', 'to_seconds', or 'At' in meta
    $stmt = $pdo->prepare("
        SELECT DISTINCT ve.session_id
        FROM video_events ve
        WHERE JSON_CONTAINS_PATH(ve.meta, 'one', '$.from_seconds')
           OR JSON_CONTAINS_PATH(ve.meta, 'one', '$.to_seconds')
           OR JSON_CONTAINS_PATH(ve.meta, 'one', '$.At')
        LIMIT 5
    ");
    $stmt->execute();
    $sessions = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (empty($sessions)) {
        echo "No sessions found with 'from_seconds', 'to_seconds', or 'At' in meta.\n";
        // Fallback: get any session with events
        $stmt2 = $pdo->prepare("SELECT session_id FROM video_sessions LIMIT 1");
        $stmt2->execute();
        $fallback = $stmt2->fetch(PDO::FETCH_COLUMN);
        if ($fallback) {
            echo "Using fallback session: $fallback\n";
            $sessions = [$fallback];
        }
    } else {
        echo "Sessions with relevant meta keys:\n";
        foreach ($sessions as $session) {
            echo "- $session\n";
        }
    }

    if (!empty($sessions)) {
        echo "\nFirst session ID: " . $sessions[0] . "\n";
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
