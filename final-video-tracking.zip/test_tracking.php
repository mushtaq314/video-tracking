<?php
/**
 * Video Tracking Backend Test Script
 *
 * This script tests the video tracking functionality by simulating frontend data
 * and sending it to the save_tracking.php endpoint. It verifies that data is
 * properly stored in the database and provides detailed feedback about the test results.
 *
 * Usage: Run this script from command line or web browser to test the tracking system.
 */

// Configuration
define('TRACKING_ENDPOINT', 'http://localhost/video-tracking/save_tracking.php');
define('TIMEOUT_SECONDS', 10);

/**
 * Generate sample tracking data for testing
 *
 * @param string $sessionId Optional custom session ID
 * @return array Sample tracking data structure
 */
function generateSampleTrackingData($sessionId = null) {
    $timestamp = date('c');
    $sessionId = $sessionId ?: 'test_session_' . time() . '_' . rand(1000, 9999);

    return [
        'session_id' => $sessionId,
        'events' => [
            [
                'type' => 'play',
                'time' => 0.0,
                'ts' => $timestamp,
                'payload' => ['at' => 0.0]
            ],
            [
                'type' => 'timeupdate',
                'time' => 2.5,
                'ts' => date('c', strtotime('+2 seconds')),
                'payload' => ['at' => 2.5]
            ],
            [
                'type' => 'pause',
                'time' => 5.5,
                'ts' => date('c', strtotime('+5 seconds')),
                'payload' => ['at' => 5.5]
            ],
            [
                'type' => 'seeked',
                'time' => 10.0,
                'ts' => date('c', strtotime('+7 seconds')),
                'payload' => ['from' => 5.5, 'to' => 10.0, 'skipped' => false]
            ],
            [
                'type' => 'tab_change',
                'time' => 0.0,
                'ts' => date('c', strtotime('+10 seconds')),
                'payload' => ['action' => 'hidden', 'total_time_on_page' => 15000]
            ],
            [
                'type' => 'ended',
                'time' => 15.2,
                'ts' => date('c', strtotime('+15 seconds')),
                'payload' => ['at' => 15.2, 'watch_ms' => 15200]
            ]
        ],
        'summary' => [
            'watch_ms' => 15200,           // 15.2 seconds in milliseconds
            'last_position' => 15.2,       // Last position in video
            'total_time_on_page' => 25000, // 25 seconds total on page
            'total_plays' => 1,
            'total_pauses' => 1,
            'total_tab_changes' => 1,
            'ts' => $timestamp
        ]
    ];
}

/**
 * Send tracking data to the endpoint using cURL
 *
 * @param array $data Tracking data to send
 * @return array Response data with status, code, and body
 */
function sendTrackingData($data) {
    $jsonData = json_encode($data);

    if ($jsonData === false) {
        return [
            'success' => false,
            'error' => 'Failed to encode JSON data',
            'http_code' => 0,
            'response' => null
        ];
    }

    $ch = curl_init(TRACKING_ENDPOINT);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $jsonData,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($jsonData)
        ],
        CURLOPT_TIMEOUT => TIMEOUT_SECONDS,
        CURLOPT_SSL_VERIFYPEER => false, // For local testing
        CURLOPT_SSL_VERIFYHOST => false  // For local testing
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);

    curl_close($ch);

    if ($curlError) {
        return [
            'success' => false,
            'error' => 'cURL Error: ' . $curlError,
            'http_code' => $httpCode,
            'response' => $response
        ];
    }

    return [
        'success' => true,
        'http_code' => $httpCode,
        'response' => $response,
        'data' => $data
    ];
}

/**
 * Verify that the tracking data was properly stored in the database
 *
 * @param string $sessionId Session ID to verify
 * @return array Verification results
 */
function verifyDatabaseStorage($sessionId) {
    require_once 'db.php';

    try {
        // Check session data
        $sessionStmt = $pdo->prepare("
            SELECT session_id, last_position, watch_ms, total_time_on_page,
                   total_plays, total_pauses, total_tab_changes, updated_at
            FROM video_sessions
            WHERE session_id = ?
        ");
        $sessionStmt->execute([$sessionId]);
        $session = $sessionStmt->fetch(PDO::FETCH_ASSOC);

        if (!$session) {
            return [
                'success' => false,
                'error' => 'Session not found in database',
                'session' => null,
                'events_count' => 0
            ];
        }

        // Check events count
        $eventsStmt = $pdo->prepare("
            SELECT COUNT(*) as event_count,
                   GROUP_CONCAT(DISTINCT event_type ORDER BY event_type) as event_types
            FROM video_events
            WHERE session_id = ?
        ");
        $eventsStmt->execute([$sessionId]);
        $eventsInfo = $eventsStmt->fetch(PDO::FETCH_ASSOC);

        return [
            'success' => true,
            'session' => $session,
            'events_count' => (int)$eventsInfo['event_count'],
            'event_types' => $eventsInfo['event_types'] ?: ''
        ];

    } catch (PDOException $e) {
        return [
            'success' => false,
            'error' => 'Database error: ' . $e->getMessage(),
            'session' => null,
            'events_count' => 0
        ];
    }
}

/**
 * Format test results for display
 *
 * @param array $sendResult Result from sendTrackingData
 * @param array $verifyResult Result from verifyDatabaseStorage
 * @return string Formatted results
 */
function formatTestResults($sendResult, $verifyResult) {
    $output = "\n" . str_repeat("=", 60) . "\n";
    $output .= "VIDEO TRACKING TEST RESULTS\n";
    $output .= str_repeat("=", 60) . "\n\n";

    // Request Results
    $output .= "📤 REQUEST RESULTS:\n";
    $output .= "- Endpoint: " . TRACKING_ENDPOINT . "\n";
    $output .= "- Session ID: " . $sendResult['data']['session_id'] . "\n";
    $output .= "- Events Sent: " . count($sendResult['data']['events']) . "\n";
    $output .= "- HTTP Status: " . $sendResult['http_code'] . "\n";

    if ($sendResult['success']) {
        $output .= "- Status: ✅ SUCCESS\n";

        // Try to decode and display response
        $responseData = json_decode($sendResult['response'], true);
        if ($responseData) {
            $output .= "- Response: " . json_encode($responseData, JSON_PRETTY_PRINT) . "\n";
        } else {
            $output .= "- Raw Response: " . substr($sendResult['response'], 0, 200) . "...\n";
        }
    } else {
        $output .= "- Status: ❌ FAILED\n";
        $output .= "- Error: " . $sendResult['error'] . "\n";
    }

    $output .= "\n";

    // Database Verification
    $output .= "🗄️  DATABASE VERIFICATION:\n";

    if ($verifyResult['success']) {
        $output .= "- Status: ✅ SUCCESS\n";
        $output .= "- Session Found: Yes\n";
        $output .= "- Events Stored: " . $verifyResult['events_count'] . "\n";
        $output .= "- Event Types: " . $verifyResult['event_types'] . "\n";

        $session = $verifyResult['session'];
        $output .= "\n📊 SESSION DATA:\n";
        $output .= "- Last Position: " . number_format($session['last_position'], 1) . "s\n";
        $output .= "- Watch Time: " . number_format($session['watch_ms'] / 1000, 1) . "s\n";
        $output .= "- Time on Page: " . number_format($session['total_time_on_page'] / 1000, 1) . "s\n";
        $output .= "- Plays: " . $session['total_plays'] . "\n";
        $output .= "- Pauses: " . $session['total_pauses'] . "\n";
        $output .= "- Tab Changes: " . $session['total_tab_changes'] . "\n";
        $output .= "- Last Updated: " . $session['updated_at'] . "\n";
    } else {
        $output .= "- Status: ❌ FAILED\n";
        $output .= "- Error: " . $verifyResult['error'] . "\n";
    }

    $output .= "\n" . str_repeat("=", 60) . "\n";

    // Overall Test Status
    $overallSuccess = $sendResult['success'] && $verifyResult['success'];
    $output .= "🎯 OVERALL TEST STATUS: " . ($overallSuccess ? "✅ PASSED" : "❌ FAILED") . "\n";
    $output .= str_repeat("=", 60) . "\n";

    return $output;
}

/**
 * Run the complete tracking test
 */
function runTrackingTest() {
    echo "🚀 Starting Video Tracking Backend Test...\n\n";

    // Generate test data
    $testData = generateSampleTrackingData();
    echo "📋 Generated test data for session: {$testData['session_id']}\n";

    // Send tracking data
    echo "📤 Sending tracking data to endpoint...\n";
    $sendResult = sendTrackingData($testData);

    // Wait a moment for processing
    sleep(1);

    // Verify database storage
    echo "🗄️  Verifying database storage...\n";
    $verifyResult = verifyDatabaseStorage($testData['session_id']);

    // Display results
    echo formatTestResults($sendResult, $verifyResult);

    // Return overall success status
    return $sendResult['success'] && $verifyResult['success'];
}

// Run the test when script is executed
if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    // Command line or direct access
    $success = runTrackingTest();

    if ($success) {
        echo "\n🎉 Test completed successfully!\n";
        exit(0);
    } else {
        echo "\n💥 Test failed! Check the output above for details.\n";
        exit(1);
    }
} else {
    // Web access - display results in HTML
    header('Content-Type: text/html; charset=utf-8');
    echo "<!DOCTYPE html><html><head><title>Tracking Test Results</title>";
    echo "<style>body{font-family:monospace;white-space:pre-wrap;padding:20px;}</style>";
    echo "</head><body>";

    $success = runTrackingTest();

    echo "<h2>Test " . ($success ? "PASSED ✅" : "FAILED ❌") . "</h2>";
    echo "</body></html>";
}
