<?php
require_once "db.php";

// Fetch all sessions from video_events
$sessions = $pdo->query("
    SELECT session_id
    FROM video_events
    GROUP BY session_id
    ORDER BY MAX(ts) DESC
")->fetchAll();

function calculateSessionMetrics($session_id) {
    global $pdo;

    // Get all events for this session
    $stmt = $pdo->prepare("SELECT * FROM video_events WHERE session_id = ? ORDER BY id ASC");
    $stmt->execute([$session_id]);
    $events = $stmt->fetchAll();

    $total_plays = 0;
    $total_pauses = 0;
    $total_tab_changes = 0;
    $total_time_on_page = 0;
    $last_position = 0;
    $last_timestamp = null;
    $pause_timestamps = [];
    $play_timestamps = [];
    
    foreach ($events as $event) {
        $meta = json_decode($event['meta'], true) ?: [];

        // Count plays, pauses, tab changes
        if ($event['event_type'] == 'play') {
            $total_plays++;
            $play_timestamps[] = $event['ts'];  // Track play timestamps
        } elseif ($event['event_type'] == 'pause') {
            $total_pauses++;
            $pause_timestamps[] = $event['ts'];  // Track pause timestamps
        } elseif ($event['event_type'] == 'tab_change') {
            $total_tab_changes++;
            $meta_action = $meta['action'] ?? null;

            // Handle total time on page for tab change
            if (isset($meta['total_time_on_page']) && is_numeric($meta['total_time_on_page'])) {
                $total_time_on_page = $meta['total_time_on_page'];
            }
        }

        // Update last position (in seconds)
        if (isset($meta['at']) && is_numeric($meta['at'])) {
            $last_position = $meta['at'];
            $last_timestamp = $event['ts'];
        }
    }

    // Calculate the most frequent pause/play timestamps
    $pause_freq = array_count_values($pause_timestamps);
    $play_freq = array_count_values($play_timestamps);

    arsort($pause_freq);
    arsort($play_freq);

    return [
        'total_plays' => $total_plays,
        'total_pauses' => $total_pauses,
        'total_tab_changes' => $total_tab_changes,
        'total_time_on_page' => round($total_time_on_page / 60000, 2), // minutes
        'last_position' => $last_position,
        'last_timestamp' => $last_timestamp,
        'pause_freq' => $pause_freq,
        'play_freq' => $play_freq,
    ];
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Video Tracking Report</title>
<style>
table {
    width: 100%; 
    border-collapse: collapse; 
    margin: 20px 0;
}
th, td {
    padding: 10px; 
    border: 1px solid #ddd; 
    font-size: 14px;
}
th { background: #333; color: #fff; }
.json-box {
    background: #f7f7f7; 
    padding: 8px; 
    border: 1px solid #ccc;
    font-family: monospace;
    white-space: pre-wrap;
}
</style>
</head>
<body>
<h1>📊 Webinar Video Tracking Report</h1>
<hr>

<h2>🎥 All Sessions Summary</h2>
<table>
<tr>
    <th>Session ID</th>
    <th>Last Position (sec)</th>
    <th>Watch Time (min)</th>
    <th>Total Plays</th>
    <th>Total Pauses</th>
    <th>Total Tab Changes</th>
    <th>Most Frequent Paused Timestamps</th>
    <th>Most Frequent Played Timestamps</th>
    <th>View</th>
</tr>

<?php foreach ($sessions as $s): ?>
<?php
    // Calculate metrics for each session
    $metrics = calculateSessionMetrics($s['session_id']);
?>
<tr>
    <td><?= $s['session_id'] ?></td>
    <td><?= $metrics['last_position'] ?></td>
    <td><?= $metrics['total_time_on_page'] ?></td>
    <td><?= $metrics['total_plays'] ?></td>
    <td><?= $metrics['total_pauses'] ?></td>
    <td><?= $metrics['total_tab_changes'] ?></td>
    <td>
        <?php
            // Display the most frequent paused timestamps (top 3)
            $pause_freq = array_slice($metrics['pause_freq'], 0, 3);
            echo implode(', ', array_map(fn($ts) => date('H:i:s', strtotime($ts)), array_keys($pause_freq)));
        ?>
    </td>
    <td>
        <?php
            // Display the most frequent played timestamps (top 3)
            $play_freq = array_slice($metrics['play_freq'], 0, 3);
            echo implode(', ', array_map(fn($ts) => date('H:i:s', strtotime($ts)), array_keys($play_freq)));
        ?>
    </td>
    <td><a href="session_details.php?id=<?= $s['session_id'] ?>">View Details</a></td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>
