-- Video Tracking Database Schema
-- This schema defines the tables for storing video session data and events.
-- Run this SQL script to create the database structure before using the application.

-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS video_tracking;
USE video_tracking;

-- Table to store session summaries
-- Each row represents a unique user session with aggregated metrics
CREATE TABLE IF NOT EXISTS video_sessions (
    session_id VARCHAR(50) PRIMARY KEY,          -- Unique identifier for the session
    email VARCHAR(255) NOT NULL,                 -- User's email address
    camp_name VARCHAR(255) NOT NULL,             -- User's camp name
    last_position FLOAT DEFAULT 0,               -- Last known position in the video (in seconds)
    watch_ms BIGINT DEFAULT 0,                   -- Total watch time in milliseconds
    total_time_on_page BIGINT DEFAULT 0,         -- Total time spent on the page in milliseconds
    total_plays INT DEFAULT 0,                   -- Total number of play events
    total_pauses INT DEFAULT 0,                  -- Total number of pause events
    total_tab_changes INT DEFAULT 0,             -- Total number of tab visibility changes
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP -- Last update timestamp
);

-- Table to store individual video events
-- Each row represents a specific event during a session
CREATE TABLE IF NOT EXISTS video_events (
    id INT AUTO_INCREMENT PRIMARY KEY,           -- Auto-incrementing unique ID for each event
    session_id VARCHAR(50) NOT NULL,             -- Foreign key to video_sessions.session_id
    event_type VARCHAR(50) NOT NULL,             -- Type of event (e.g., 'play', 'pause', 'seeked')
    event_time FLOAT DEFAULT 0,                  -- Time in the video when the event occurred (in seconds)
    ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP,      -- Timestamp when the event was recorded
    meta JSON,                                   -- Additional metadata for the event (stored as JSON)
    INDEX idx_session_id (session_id),           -- Index for faster queries by session_id
    INDEX idx_event_type (event_type),           -- Index for faster queries by event type
    FOREIGN KEY (session_id) REFERENCES video_sessions(session_id) ON DELETE CASCADE
);

-- Optional: Create indexes for better performance on common queries
-- These indexes help with sorting and filtering sessions by update time
CREATE INDEX IF NOT EXISTS idx_updated_at ON video_sessions (updated_at DESC);
