<?php
/**
 * Session Details Viewer
 *
 * This page displays detailed information about a specific video tracking session,
 * including all individual events with their metadata. The interface provides
 * a chronological view of user interactions with the video.
 */

require_once "db.php";

/**
 * Format seconds to MM:SS.ss format
 *
 * @param float $seconds Time in seconds
 * @return string Formatted time string
 */
function formatVideoTime($seconds) {
    $minutes = floor($seconds / 60);
    $secs = $seconds % 60;
    return sprintf('%02d:%05.2f', $minutes, $secs);
}

/**
 * Format timestamp for display
 *
 * @param string $timestamp ISO timestamp string
 * @return string Formatted date/time string
 */
/*function formatTimestamp($timestamp) {
    return date('M j, Y g:i:s A', strtotime($timestamp));
}*/

function formatTimestamp($timestamp) {
    // Create a DateTime object from the timestamp and set the timezone to GMT
    $date = new DateTime($timestamp, new DateTimeZone('GMT'));

    // Set the timezone to IST (Indian Standard Time)
    $date->setTimezone(new DateTimeZone('Asia/Kolkata'));

    // Format the timestamp in the desired format
    return $date->format('M j, Y g:i A');
}


/**
 * Get event type display name and color
 *
 * @param string $eventType Raw event type
 * @return array Array with 'name' and 'color' keys
 */
function getEventDisplayInfo($eventType) {
    $eventTypes = [
        'play' => ['name' => 'Play', 'color' => '#4CAF50'],
        'pause' => ['name' => 'Pause', 'color' => '#FF9800'],
        'ended' => ['name' => 'Video Ended', 'color' => '#9C27B0'],
        'seeking_start' => ['name' => 'Seeking Start', 'color' => '#2196F3'],
        'seeked' => ['name' => 'Seeked', 'color' => '#00BCD4'],
        'timeupdate' => ['name' => 'Time Update', 'color' => '#607D8B'],
        'loadedmetadata' => ['name' => 'Metadata Loaded', 'color' => '#795548'],
        'tab_change' => ['name' => 'Tab Change', 'color' => '#FF5722'],
        'unknown' => ['name' => 'Unknown', 'color' => '#9E9E9E']
    ];

    return $eventTypes[$eventType] ?? $eventTypes['unknown'];
}

// Get and validate email from URL parameter
$email = $_GET['email'] ?? null;
if (!$email) {
    header("Location: reports.php");
    exit;
}

// Sanitize email
$email = trim($email);

try {
    // Fetch all sessions for this email
    $sessionsStmt = $pdo->prepare("SELECT * FROM video_sessions WHERE email = ? ORDER BY updated_at DESC");
    $sessionsStmt->execute([$email]);
    $userSessions = $sessionsStmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($userSessions)) {
        http_response_code(404);
        die("Error: No sessions found for this email.");
    }

    // Aggregate session data
    $sessionData = [
        'email' => $email,
        'total_sessions' => count($userSessions),
        'last_position' => $userSessions[0]['last_position'], // Most recent
        'watch_ms' => array_sum(array_column($userSessions, 'watch_ms')),
        'total_time_on_page' => array_sum(array_column($userSessions, 'total_time_on_page')),
        'total_plays' => array_sum(array_column($userSessions, 'total_plays')),
        'total_pauses' => array_sum(array_column($userSessions, 'total_pauses')),
        'total_tab_changes' => array_sum(array_column($userSessions, 'total_tab_changes')),
        'updated_at' => $userSessions[0]['updated_at'] // Most recent
    ];

    // Fetch all events for all sessions of this email
    $sessionIds = array_column($userSessions, 'session_id');
    $placeholders = str_repeat('?,', count($sessionIds) - 1) . '?';
    $eventsStmt = $pdo->prepare("
        SELECT id, event_type, event_time, ts, meta, session_id
        FROM video_events
        WHERE session_id IN ($placeholders)
        ORDER BY ts ASC
    ");
    $eventsStmt->execute($sessionIds);
    $events = $eventsStmt->fetchAll(PDO::FETCH_ASSOC);

    // Collect unique metadata keys for dynamic table columns
    $uniqueMetaKeys = [];
    foreach ($events as $event) {
        $meta = json_decode($event['meta'], true);
        if ($meta && is_array($meta)) {
            foreach ($meta as $key => $value) {
                if (!in_array($key, $uniqueMetaKeys)) {
                    $uniqueMetaKeys[] = $key;
                }
            }
        }
    }

    // Sort metadata keys for consistent display
    sort($uniqueMetaKeys);

} catch (PDOException $e) {
    error_log("Database error in session_details.php: " . $e->getMessage());
    http_response_code(500);
    die("Error loading session details. Please try again later.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Details - <?php echo htmlspecialchars($email); ?></title>
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f8f9fa;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
        }

        .header h1 {
            font-size: 2em;
            margin-bottom: 10px;
        }

        .session-info {
            background: #f8f9fa;
            padding: 20px;
            border-bottom: 1px solid #dee2e6;
        }

        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }

        .info-item {
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .info-label {
            font-weight: 600;
            color: #666;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }

        .info-value {
            font-size: 1.2em;
            color: #333;
            font-weight: 600;
        }

        .events-section {
            padding: 30px;
        }

        .section-title {
            font-size: 1.8em;
            margin-bottom: 20px;
            color: #333;
            border-bottom: 2px solid #667eea;
            padding-bottom: 10px;
        }

        .table-container {
            overflow-x: auto;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #667eea;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.85em;
            letter-spacing: 0.5px;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        tr:nth-child(even) {
            background: #f8f9fa;
        }

        tr:hover {
            background: #e3f2fd;
            transition: background-color 0.3s ease;
        }

        .event-type {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            color: white;
            font-size: 0.8em;
            font-weight: 600;
            text-transform: uppercase;
        }

        .time-cell {
            font-family: 'Courier New', monospace;
            font-weight: 600;
            color: #333;
        }

        .timestamp-cell {
            font-size: 0.9em;
            color: #666;
        }

        .meta-cell {
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }

        .no-events {
            text-align: center;
            padding: 40px;
            color: #666;
            font-style: italic;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }

        .back-link:hover {
            background: #5a6268;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.5em;
            }

            .info-grid {
                grid-template-columns: 1fr;
            }

            .events-section {
                padding: 20px;
            }

            th, td {
                padding: 8px 10px;
                font-size: 0.9em;
            }

            .table-container {
                font-size: 0.8em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <a href="reports.php" class="back-link">← Back to Reports</a>
            <h1>📧 Email Details</h1>
            <p>Email: <strong><?php echo htmlspecialchars($email); ?></strong></p>
        </div>

        <div class="session-info">
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Total Sessions</div>
                    <div class="info-value"><?php echo $sessionData['total_sessions']; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Last Position</div>
                    <div class="info-value"><?php echo formatVideoTime($sessionData['last_position']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Watch Time</div>
                    <div class="info-value"><?php echo number_format($sessionData['watch_ms'] / 60000, 2); ?> min</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Time on Page</div>
                    <div class="info-value"><?php echo number_format($sessionData['total_time_on_page'] / 60000, 2); ?> min</div>
                </div>
                <div class="info-item">
                    <div class="info-label">Total Plays</div>
                    <div class="info-value"><?php echo $sessionData['total_plays']; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Total Pauses</div>
                    <div class="info-value"><?php echo $sessionData['total_pauses']; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Tab Changes</div>
                    <div class="info-value"><?php echo $sessionData['total_tab_changes']; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Last Updated</div>
                    <div class="info-value"><?php echo formatTimestamp($sessionData['updated_at']); ?></div>
                </div>
            </div>
        </div>

        <div class="events-section">
            <h2 class="section-title">🎬 Event Timeline (<?php echo count($events); ?> events)</h2>

            <?php if (empty($events)): ?>
                <div class="no-events">
                    <p>No events recorded for this email yet.</p>
                </div>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Email</th>
                                <th>Event Type</th>
                                <th>Video Time</th>
                                <th>Timestamp</th>
                                <?php foreach ($uniqueMetaKeys as $key): ?>
                                    <th><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $key))); ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($events as $index => $event): ?>
                                <?php
                                $eventInfo = getEventDisplayInfo($event['event_type']);
                                $meta = json_decode($event['meta'], true) ?: [];
                                ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td class="meta-cell"><?php echo htmlspecialchars($email); ?></td>
                                    <td>
                                        <span class="event-type" style="background-color: <?php echo $eventInfo['color']; ?>">
                                            <?php echo htmlspecialchars($eventInfo['name']); ?>
                                        </span>
                                    </td>
                                    <td class="time-cell"><?php echo formatVideoTime($event['event_time']); ?></td>
                                    <td class="timestamp-cell"><?php echo formatTimestamp($event['ts']); ?></td>
                                    <?php foreach ($uniqueMetaKeys as $key): ?>
                                        <td class="meta-cell">
                                            <?php
                                            $value = $meta[$key] ?? '';
                                            // Format time-related values
                                            if (in_array($key, ['at', 'from', 'to', 'duration', 'from_seconds', 'to_seconds', 'At']) && is_numeric($value)) {
                                                $value = formatVideoTime($value);
                                            }
                                            echo htmlspecialchars($value);
                                            ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
