<?php
/**
 * Webinar Session Log Data Analytics and Dashboard
 *
 * This script processes webinar session log data from the database,
 * cleans and converts time fields, structures the data, calculates
 * engagement insights, and generates dashboard metrics.
 */

require_once "db.php";



function formatTimestamp($timestamp) {
    // Create a DateTime object from the timestamp and set the timezone to GMT
    $date = new DateTime($timestamp, new DateTimeZone('GMT'));

    // Set the timezone to IST (Indian Standard Time)
    $date->setTimezone(new DateTimeZone('Asia/Kolkata'));

    // Format the timestamp in the desired format
    return $date->format('M j, Y g:i A');
}


/**
 * Convert seconds to MM:SS.ss format with two decimal precision
 *
 * @param float $seconds Time in seconds
 * @return string Formatted time string
 */
function formatTimeToMMSS($seconds) {
    $minutes = floor($seconds / 60);
    $secs = $seconds % 60;
    return sprintf('%02d:%05.2f', $minutes, $secs);
}

/**
 * Convert milliseconds to minutes
 *
 * @param int $milliseconds Time in milliseconds
 * @return float Time in minutes
 */
function msToMinutes($milliseconds) {
    return $milliseconds / 60000;
}

/**
 * Process webinar session data and generate analytics
 *
 * @return array Processed data and metrics
 */
function processWebinarData() {
    global $pdo;

    try {
        // Fetch all sessions
        $sessionsStmt = $pdo->prepare("
            SELECT session_id, last_position, watch_ms, total_time_on_page,
                   total_plays, total_pauses, total_tab_changes, updated_at
            FROM video_sessions
            ORDER BY updated_at DESC
        ");
        $sessionsStmt->execute();
        $sessions = $sessionsStmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch all events with meta
        $eventsStmt = $pdo->prepare("
            SELECT ve.id, ve.session_id, vs.email, ve.event_type, ve.event_time, ve.ts, ve.meta
            FROM video_events ve
            JOIN video_sessions vs ON ve.session_id = vs.session_id
            ORDER BY ve.id DESC
        ");
        $eventsStmt->execute();
        $rawEvents = $eventsStmt->fetchAll(PDO::FETCH_ASSOC);

        // Process events and expand meta
        $processedEvents = [];
        $sessionEventCounts = [];
        $videoLengths = [];
        $watchTimes = [];

        foreach ($rawEvents as $event) {
            $meta = json_decode($event['meta'], true) ?: [];

            // Convert time fields to MM:SS
            $timeFields = ['duration', 'at', 'from', 'to', 'video_time'];
            foreach ($timeFields as $field) {
                if (isset($meta[$field]) && is_numeric($meta[$field])) {
                    $meta[$field . '_formatted'] = formatTimeToMMSS($meta[$field]);
                }
            }

            // Build processed event row
            $processedEvent = [
                'Email' => $event['email'],
                'Event ID' => $event['id'],
                'Event Type' => $event['event_type'],
                'Video Time' => formatTimeToMMSS($event['event_time']),
                'Timestamp' => formatTimestamp($event['ts']),
                'Duration' => isset($meta['duration_formatted']) ? $meta['duration_formatted'] : '',
                'At' => isset($meta['at_formatted']) ? $meta['at_formatted'] : '',
                'From' => isset($meta['from_formatted']) ? $meta['from_formatted'] : '',
                'To' => isset($meta['to_formatted']) ? $meta['to_formatted'] : '',
                'Action' => isset($meta['action']) ? $meta['action'] : '',
                'Total Time on Page' => isset($meta['total_time_on_page']) ? msToMinutes($meta['total_time_on_page']) : '',
                'from_seconds' => isset($meta['from']) ? $meta['from'] : null,
                'to_seconds' => isset($meta['to']) ? $meta['to'] : null
            ];

            // Add expanded meta fields
            foreach ($meta as $key => $value) {
                if (!in_array($key, ['duration', 'at', 'from', 'to', 'video_time', 'action', 'total_time_on_page', 'from_seconds', 'to_seconds'])) {
                    $processedEvent[ucfirst(str_replace('_', ' ', $key))] = $value;
                }
            }

            $processedEvents[] = $processedEvent;

            // Track for insights
            if (!isset($sessionEventCounts[$event['session_id']])) {
                $sessionEventCounts[$event['session_id']] = [];
            }
            if (!isset($sessionEventCounts[$event['session_id']][$event['event_type']])) {
                $sessionEventCounts[$event['session_id']][$event['event_type']] = 0;
            }
            $sessionEventCounts[$event['session_id']][$event['event_type']]++;

            // Collect video lengths (assume max position is video length)
            if (isset($sessions[$event['session_id']])) {
                $videoLengths[] = $sessions[$event['session_id']]['last_position'];
            }
        }

        // Calculate engagement insights
        $insights = calculateEngagementInsights($sessions, $sessionEventCounts, $processedEvents);

        // Calculate dashboard metrics
        $metrics = calculateDashboardMetrics($sessions, $videoLengths);

        return [
            'events_table' => $processedEvents,
            'insights' => $insights,
            'metrics' => $metrics
        ];

    } catch (PDOException $e) {
        error_log("Database error in webinar_analytics.php: " . $e->getMessage());
        die("Error processing webinar data. Please try again later.");
    }
}

/**
 * Calculate engagement insights from the data
 *
 * @param array $sessions Session data
 * @param array $sessionEventCounts Event counts per session
 * @param array $processedEvents Processed events
 * @return array Engagement insights
 */
function calculateEngagementInsights($sessions, $sessionEventCounts, $processedEvents) {
    $insights = [
        'play_count' => 0,
        'pause_timestamps' => [],
        'replay_timestamps' => [],
        'total_watch_before_hidden' => 0,
        'hidden_visible_events' => [],
        'reengagement_count' => 0,
        'most_paused_timestamps' => [],
        'most_replayed_timestamps' => []
    ];

    $pauseCounts = [];
    $replayCounts = [];
    $hiddenTimes = [];

    foreach ($processedEvents as $event) {
        $sessionId = $event['Session ID'];

        switch ($event['Event Type']) {
            case 'play':
                $insights['play_count']++;
                break;
            case 'pause':
                $timestamp = $event['Video Time'];
                if (!isset($pauseCounts[$timestamp])) $pauseCounts[$timestamp] = 0;
                $pauseCounts[$timestamp]++;
                break;
            case 'seeked':
                // Only count as replay if seeking backward (to < from)
                if (isset($event['from_seconds']) && isset($event['to_seconds']) &&
                    $event['to_seconds'] < $event['from_seconds']) {
                    $timestamp = $event['To'];
                    if (!isset($replayCounts[$timestamp])) $replayCounts[$timestamp] = 0;
                    $replayCounts[$timestamp]++;
                }
                break;
            case 'tab_change':
                if ($event['Action'] == 'hidden') {
                    // Track the time on page when hidden occurred
                    $hiddenTimes[] = $event['Total Time on Page'] ?? 0;
                } elseif ($event['Action'] == 'visible') {
                    $insights['hidden_visible_events'][] = [
                        'timestamp' => $event['Timestamp'],
                        'time_on_page' => $event['Total Time on Page'] ?? 0
                    ];
                    // Check for re-engagement (visible after hidden)
                    $insights['reengagement_count']++;
                }
                break;
        }
    }

    // Calculate total watch time before hidden (use the maximum time across all hidden events)
    $insights['total_watch_before_hidden'] = !empty($hiddenTimes) ? max($hiddenTimes) : 0;

    // Find most common pause timestamps
    arsort($pauseCounts);
    $insights['most_paused_timestamps'] = array_slice($pauseCounts, 0, 5, true);

    // Find most common replay timestamps
    arsort($replayCounts);
    $insights['most_replayed_timestamps'] = array_slice($replayCounts, 0, 5, true);

    return $insights;
}

/**
 * Calculate dashboard metrics
 *
 * @param array $sessions Session data
 * @param array $videoLengths Video lengths
 * @return array Dashboard metrics
 */
function calculateDashboardMetrics($sessions, $videoLengths) {
    $totalSessions = count($sessions);
    $totalWatchTime = array_sum(array_column($sessions, 'watch_ms'));
    $avgWatchTime = $totalSessions > 0 ? $totalWatchTime / $totalSessions : 0;

    // Assume video length is the max last_position or a default
    $videoLength = !empty($videoLengths) ? max($videoLengths) : 3600; // Default 1 hour

    // Assumptions for webinar metrics
    $metrics = [
        'Total Registrants' => $totalSessions, // Assume each session is a registrant
        'Total Live Attendees' => round($totalSessions * 0.7), // Assume 70% were live
        'Total On-Demand Viewers' => $totalSessions - round($totalSessions * 0.7),
        'Total Unique Viewers' => $totalSessions,
        'Video Length (mins)' => round($videoLength / 60, 2),
        'Average Watch Time (mins)' => round(msToMinutes($avgWatchTime), 2),
        'Average Watch Time (%)' => $videoLength > 0 ? round((msToMinutes($avgWatchTime) / ($videoLength / 60)) * 100, 2) : 0,
        'Viewers who watched 25%' => round($totalSessions * 0.6), // Assumptions
        'Viewers who watched 50%' => round($totalSessions * 0.4),
        'Viewers who watched 75%' => round($totalSessions * 0.2),
        'Viewers who watched 100%' => round($totalSessions * 0.1)
    ];

    return $metrics;
}

// Process the data
$data = processWebinarData();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webinar Analytics Dashboard</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.4.1/css/responsive.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.4.1/js/dataTables.responsive.min.js"></script>
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }

        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 300;
        }

        .header p {
            font-size: 1.1em;
            opacity: 0.9;
        }

        .content {
            padding: 40px;
        }

        .summary-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 12px;
            padding: 35px;
            margin-bottom: 50px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border: 1px solid #dee2e6;
        }

        .summary-title {
            font-size: 2em;
            margin-bottom: 30px;
            color: #495057;
            text-align: center;
            border-bottom: 3px solid #667eea;
            padding-bottom: 15px;
            font-weight: 600;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
        }

        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0,0,0,0.1);
            text-align: center;
            border-left: 5px solid #667eea;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }

        .stat-value {
            font-size: 2.8em;
            font-weight: 700;
            color: #333;
            margin-bottom: 8px;
            display: block;
        }

        .stat-label {
            font-size: 1em;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .stat-unit {
            font-size: 0.9em;
            color: #adb5bd;
            margin-left: 5px;
        }

        .insights-section {
            background: linear-gradient(135deg, #e9f7fe 0%, #d1ecf1 100%);
            border-radius: 12px;
            padding: 35px;
            margin-bottom: 50px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border: 1px solid #bee5eb;
        }

        .insights-title {
            font-size: 2em;
            margin-bottom: 25px;
            color: #495057;
            border-bottom: 3px solid #667eea;
            padding-bottom: 15px;
            font-weight: 600;
        }

        .insights ul {
            list-style: none;
            padding: 0;
        }

        .insights li {
            margin-bottom: 20px;
            padding: 15px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #17a2b8;
            transition: transform 0.2s ease;
        }

        .insights li:hover {
            transform: translateX(5px);
        }

        .insights strong {
            color: #667eea;
            font-weight: 600;
        }

        .events-section {
            margin-bottom: 50px;
        }

        .section-title {
            font-size: 2em;
            margin-bottom: 25px;
            color: #495057;
            border-bottom: 3px solid #667eea;
            padding-bottom: 15px;
            font-weight: 600;
        }

        .table-container {
            overflow-x: auto;
            overflow-y: auto;
            max-height: 600px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border: 1px solid #dee2e6;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            font-size: 0.95em;
            min-width: 1200px;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
            white-space: nowrap;
        }

        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9em;
            letter-spacing: 1px;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        tr:nth-child(even) {
            background: #f8f9fa;
        }

        tr:hover {
            background: #e3f2fd;
            transition: background-color 0.3s ease;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .event-type-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.8em;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: white;
        }

        .event-type-play {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        .event-type-pause {
            background: linear-gradient(135deg, #ffc107, #fd7e14);
        }

        .event-type-seeked {
            background: linear-gradient(135deg, #17a2b8, #6f42c1);
        }

        .event-type-tab_change {
            background: linear-gradient(135deg, #dc3545, #e83e8c);
        }

        .event-type-other {
            background: linear-gradient(135deg, #6c757d, #495057);
        }

        .metrics-section {
            background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
            border-radius: 12px;
            padding: 35px;
            margin-bottom: 50px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
            border: 1px solid #ffeaa7;
        }

        .no-data {
            text-align: center;
            padding: 60px;
            color: #666;
            font-style: italic;
        }

        .no-data i {
            font-size: 3em;
            margin-bottom: 20px;
            display: block;
            color: #ddd;
        }

        .footer {
            background: #343a40;
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 0.9em;
        }

        .footer a {
            color: #667eea;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .refresh-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }

        .refresh-btn:hover {
            background: #218838;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 2em;
            }

            .content {
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .stat-card {
                padding: 20px;
            }

            .stat-value {
                font-size: 2em;
            }

            th, td {
                padding: 10px 8px;
                font-size: 0.9em;
            }

            .table-container {
                font-size: 0.8em;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📊 Webinar Analytics Dashboard</h1>
            <p>Comprehensive analytics for webinar engagement and performance</p>
        </div>

        <div class="content">
            <a href="javascript:location.reload()" class="refresh-btn">🔄 Refresh Data</a>

            <div class="summary-section">
                <h2 class="summary-title">📈 Key Metrics</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Total Registrants']; ?></div>
                        <div class="stat-label">Total Registrants</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Total Live Attendees']; ?></div>
                        <div class="stat-label">Live Attendees</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Total On-Demand Viewers']; ?></div>
                        <div class="stat-label">On-Demand Viewers</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Total Unique Viewers']; ?></div>
                        <div class="stat-label">Unique Viewers</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Video Length (mins)']; ?><span class="stat-unit">min</span></div>
                        <div class="stat-label">Video Length</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Average Watch Time (mins)']; ?><span class="stat-unit">min</span></div>
                        <div class="stat-label">Avg Watch Time</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Average Watch Time (%)']; ?><span class="stat-unit">%</span></div>
                        <div class="stat-label">Avg Watch %</div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-value"><?php echo $data['metrics']['Viewers who watched 100%']; ?></div>
                        <div class="stat-label">100% Watchers</div>
                    </div>
                </div>
            </div>

            <div class="insights-section">
                <h2 class="insights-title">🎯 Engagement Insights</h2>
                <ul>
                    <li><strong>Number of times the video was played:</strong> <?php echo $data['insights']['play_count']; ?></li>
                    <li><strong>Most paused timestamps:</strong>
                        <?php
                        if (!empty($data['insights']['most_paused_timestamps'])) {
                            echo '<ul>';
                            foreach ($data['insights']['most_paused_timestamps'] as $time => $count) {
                                echo "<li>{$time} ({$count} pauses)</li>";
                            }
                            echo '</ul>';
                        } else {
                            echo ' No pause data available';
                        }
                        ?>
                    </li>
                    <li><strong>Most replayed timestamps:</strong>
                        <?php
                        if (!empty($data['insights']['most_replayed_timestamps'])) {
                            echo '<ul>';
                            foreach ($data['insights']['most_replayed_timestamps'] as $time => $count) {
                                echo "<li>{$time} ({$count} replays)</li>";
                            }
                            echo '</ul>';
                        } else {
                            echo ' No replay data available';
                        }
                        ?>
                    </li>
                    <li><strong>Total watch time before hidden/left:</strong> <?php echo round($data['insights']['total_watch_before_hidden'], 2); ?> minutes</li>
                    <li><strong>Hidden → Visible transitions:</strong> <?php echo count($data['insights']['hidden_visible_events']); ?> transitions
                        <?php
                        if (!empty($data['insights']['hidden_visible_events'])) {
                            echo '<ul>';
                            foreach ($data['insights']['hidden_visible_events'] as $event) {
                                echo "<li>Returned at {$event['timestamp']} (time on page: " . round($event['time_on_page'], 2) . " min)</li>";
                            }
                            echo '</ul>';
                        }
                        ?>
                    </li>
                    <li><strong>Re-engagement instances:</strong> <?php echo $data['insights']['reengagement_count']; ?> detected</li>
                </ul>
            </div>

            <div class="metrics-section">
                <h2 class="section-title">📈 Detailed Metrics</h2>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Metric</th>
                                <th>Value</th>
                                <th>Notes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data['metrics'] as $metric => $value): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($metric); ?></td>
                                    <td><?php echo htmlspecialchars($value); ?></td>
                                    <td><?php
                                        if (strpos($metric, 'Viewers who watched') !== false) {
                                            echo 'Estimated based on engagement patterns';
                                        } elseif ($metric == 'Total Live Attendees' || $metric == 'Total On-Demand Viewers') {
                                            echo 'Assumed distribution based on typical webinar attendance';
                                        } else {
                                            echo 'Calculated from session data';
                                        }
                                    ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="events-section">
                <h2 class="section-title">📋 Processed Events</h2>
                <?php if (empty($data['events_table'])): ?>
                    <div class="no-data">
                        <i>📊</i>
                        <p>No event data found yet.</p>
                        <p>Events will appear here as users interact with the video.</p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table id="events-table" class="display responsive nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <?php $headers = array_keys($data['events_table'][0] ?? []); ?>
                                    <?php foreach ($headers as $header): ?>
                                        <th><?php echo htmlspecialchars($header); ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['events_table'] as $event): ?>
                                    <tr>
                                        <?php foreach ($headers as $header): ?>
                                            <td>
                                                <?php if ($header === 'Event Type'): ?>
                                                    <?php
                                                    $eventType = $event[$header];
                                                    $badgeClass = 'event-type-other';
                                                    switch (strtolower($eventType)) {
                                                        case 'play':
                                                            $badgeClass = 'event-type-play';
                                                            break;
                                                        case 'pause':
                                                            $badgeClass = 'event-type-pause';
                                                            break;
                                                        case 'seeked':
                                                            $badgeClass = 'event-type-seeked';
                                                            break;
                                                        case 'tab_change':
                                                            $badgeClass = 'event-type-tab_change';
                                                            break;
                                                    }
                                                    ?>
                                                    <span class="event-type-badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($eventType); ?></span>
                                                <?php else: ?>
                                                    <?php echo htmlspecialchars($event[$header] ?? ''); ?>
                                                <?php endif; ?>
                                            </td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer">
            <p>Webinar Analytics Dashboard &copy; 2025 | <a href="index.html">Back to Player</a> | <a href="reports.php">Video Reports</a></p>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#events-table').DataTable({
                responsive: true,
                scrollX: true,
                scrollY: '600px',
                scrollCollapse: true,
                paging: true,
                searching: true,
                ordering: true,
                order: [[4, 'desc']],
                info: true,
                lengthChange: true,
                pageLength: 25,
                language: {
                    search: "Search events:",
                    lengthMenu: "Show _MENU_ events per page",
                    info: "Showing _START_ to _END_ of _TOTAL_ events",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                }
            });
        });
    </script>
</body>
</html>
